"""Meta package for all project packages.

This is the __init__ file for this package.

Typically this file can be left blank.

Usage:
    python3 -m src - execute this program (when run from project root).

Author: Russell Feldhausen russfeld@ksu.edu
Version: 0.1
"""

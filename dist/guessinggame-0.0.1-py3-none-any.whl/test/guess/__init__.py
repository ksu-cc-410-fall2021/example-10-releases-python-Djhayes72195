"""test package for hello.

This is the __init__ file for this package.

Typically this file can be left blank.

Author: Russell Feldhausen russfeld@ksu.edu
Version: 0.1
"""

"""Test Package for guessing game.

Author: Dustin Hayes djhayes@ksu.edu
Version: 0.1
"""
